# Tactile Touch — Android app

Feel a fabric's texture on your Android phone using **real vibration haptics + on-device ML**.
No dev team, no Android Studio, no coding required to build it — a free cloud service turns this
code into an installable app (APK) for you.

---

## What this app does

1. Pick a sample fabric (or upload a photo of one).
2. Tap **Analyze** — an on-device neural network (92.7% test accuracy) classifies the fabric and
   produces a **tactile spec**: roughness, graininess, weave density, softness, sheen.
3. **Drag your finger** across the swatch — the phone vibrates with **position-locked "thread bumps"**
   (a tap every few pixels you travel), with **real intensity + sharpness** (not just on/off), plus a
   synthesized **friction sound** that tracks your finger speed.

### Honest expectation
This is a **real haptic impression** — noticeably richer than a web page's on/off buzz because a
native app can control vibration **intensity and sharpness**. But it is still the phone's single motor
buzzing the whole body — it is **not** localized texture under your fingertip. True fingertip texture
needs surface-haptic screens (Tanvas/Hap2u), which is a hardware change.

---

## How to build the installable APK (no tools needed) — ~10 minutes

You'll use **GitHub**, which has a free cloud build service. Everything happens in your browser.

### Step 1 — Create a free GitHub account
Go to https://github.com and sign up (free) if you don't have an account.

### Step 2 — Create a new repository
1. Click the **+** (top-right) → **New repository**.
2. Name it `tactile-touch` (anything is fine).
3. Choose **Public** (free build minutes) → **Create repository**.

### Step 3 — Upload these files
1. On the new empty repo page, click **uploading an existing file** (the link in the middle).
2. Drag **the entire contents of this folder** (`tactile_touch_android/`) into the upload area.
   - Tip: keep the folder structure. The easiest way is to zip nothing — just select all files/folders
     inside `tactile_touch_android` and drag them in. GitHub preserves subfolders.
3. Scroll down → **Commit changes**.

### Step 4 — Let it build automatically
1. Click the **Actions** tab at the top of your repo.
2. You'll see a workflow named **Build Android APK** running (yellow dot). Wait ~3–5 minutes for a
   green check ✅.
   - If it asks you to enable Actions the first time, click **"I understand my workflows, enable them."**

### Step 5 — Download the APK to your phone
**Option A (easiest — permanent link):**
1. Go to the **Releases** section (right side of the repo home page, or `your-repo/releases`).
2. Open the **Tactile Touch (latest build)** release → download **app-debug.apk**.
3. Open that link **on your Android phone's browser** to download it directly.

**Option B (from the build run):**
1. **Actions** tab → click the finished green run → scroll to **Artifacts** → download **TactileTouch-apk**.
2. It's a `.zip` containing `app-debug.apk` — unzip and transfer to your phone.

### Step 6 — Install it on your phone
1. Tap the downloaded `app-debug.apk`.
2. Android will warn about "install from unknown sources" — tap **Settings → allow** for your browser/
   Files app (this is normal for apps not from the Play Store).
3. Tap **Install** → **Open**.

### Step 7 — Feel it
1. Make sure **Do Not Disturb is OFF** and vibration is enabled.
2. Turn the **friction sound** on (headphones help).
3. Pick a fabric → **Analyze** → **drag your finger** on the swatch. Try **denim** (dense, coarse bumps)
   vs. **silk** (faint, sparse). Use **🔔 Test buzz** to feel the signature anytime.

---

## Project structure

```
tactile_touch_android/
├── settings.gradle
├── build.gradle                     # top-level
├── gradle.properties
├── gradle/wrapper/…                 # wrapper config (JAR auto-generated in CI)
├── .github/workflows/build-apk.yml  # the cloud build — makes the APK for you
└── app/
    ├── build.gradle                 # app config; release signed with debug key so it installs
    └── src/main/
        ├── AndroidManifest.xml      # VIBRATE permission
        ├── res/…                    # theme, icon, strings
        └── java/com/tactiletouch/
            ├── MainActivity.kt      # the whole UI (built in code)
            ├── HapticEngine.kt      # REAL VibrationEffect: intensity + primitives + position grain
            ├── FabricClassifier.kt  # 7 texture features + neural-net forward pass
            ├── ModelWeights.kt      # trained weights (92.7% test accuracy)
            ├── FeelPadView.kt       # touch surface + stick-slip cursor
            ├── FrictionAudio.kt     # synthesized friction sound (AudioTrack)
            └── SampleTextures.kt    # procedural demo fabric swatches
```

## Device support
| Your phone | Experience |
|---|---|
| Android 11+ (API 30+) with modern motor (LRA) | **Best** — scaled haptic primitives (TICK/CLICK) |
| Android 8–10 with amplitude control | **Good** — variable-intensity pulses |
| Older phones / basic motor | **Basic** — on/off pulses (still position-locked) |
| No motor | Audio + visual only |

The app shows your phone's haptic tier in the banner at the top.

## Notes
- The **release** build is signed with the standard **debug key** on purpose, so the APK installs by
  sideloading without Play Store signing. For a real Play Store release you'd add a proper signing key.
- All ML runs **on-device**; no network calls, no data leaves the phone.
