package com.tactiletouch

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

/**
 * MainActivity — the whole Tactile Touch UI, built in code (no XML layout) so
 * the project stays compact and easy to build in the cloud.
 *
 * Flow:  pick/upload fabric  ->  Analyze (ML)  ->  Tactile spec + Feel pad.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var engine: HapticEngine
    private lateinit var friction: FrictionAudio
    private lateinit var feelPad: FeelPadView
    private lateinit var specContainer: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var confView: TextView
    private lateinit var speedView: TextView
    private lateinit var bannerView: TextView

    private var selectedBitmap: Bitmap? = null
    private var selectedKey: String? = null
    private val PICK_IMAGE = 1001

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = HapticEngine(this)
        friction = FrictionAudio()

        val bgColor = Color.parseColor("#0e1116")
        val surface = Color.parseColor("#171b22")
        val orange = Color.parseColor("#ff9900")
        val textMain = Color.parseColor("#eef1f5")
        val textDim = Color.parseColor("#9aa4b2")

        val scroll = ScrollView(this).apply { setBackgroundColor(bgColor) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(40))
        }
        scroll.addView(root)

        // ---- Header ----
        root.addView(TextView(this).apply {
            text = "🫧  Tactile Touch"
            setTextColor(textMain); textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Feel the fabric before you buy — real haptics + on-device ML."
            setTextColor(textDim); textSize = 13f
            setPadding(0, dp(4), 0, dp(16))
        })

        // ---- Capability banner ----
        bannerView = TextView(this).apply {
            text = "Device haptics: ${engine.capabilityLabel()}"
            setTextColor(Color.parseColor("#7ee0b0")); textSize = 12f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = roundedBg(Color.parseColor("#12332420"), dp(10))
        }
        root.addView(bannerView, lpVertical(dp(14)))

        // ---- Swatch picker ----
        root.addView(sectionTitle("1 · Choose a fabric"))
        val grid = GridLayout(this).apply {
            columnCount = 4
        }
        SampleTextures.keys.forEach { key ->
            val bmp = SampleTextures.generate(key, 128)
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            val iv = ImageView(this).apply {
                setImageBitmap(bmp)
                val s = dp(64)
                layoutParams = LinearLayout.LayoutParams(s, s)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            cell.addView(iv)
            cell.addView(TextView(this).apply {
                text = SampleTextures.labels[key]
                setTextColor(textDim); textSize = 10f; gravity = Gravity.CENTER
            })
            cell.setOnClickListener {
                selectedBitmap = bmp; selectedKey = key
                Toast.makeText(this, "Selected ${SampleTextures.labels[key]}", Toast.LENGTH_SHORT).show()
            }
            grid.addView(cell)
        }
        root.addView(grid, lpVertical(dp(12)))

        // ---- Upload button ----
        root.addView(Button(this).apply {
            text = "📷  Upload fabric photo"
            setOnClickListener {
                val intent = android.content.Intent(android.content.Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                }
                startActivityForResult(intent, PICK_IMAGE)
            }
        }, lpVertical(dp(8)))

        // ---- Analyze button ----
        root.addView(Button(this).apply {
            text = "✨  Analyze & generate feel"
            setBackgroundColor(orange)
            setTextColor(Color.parseColor("#1a1205"))
            setTypeface(typeface, Typeface.BOLD)
            setOnClickListener { runAnalysis() }
        }, lpVertical(dp(8)))

        // ---- Results ----
        root.addView(sectionTitle("2 · Result"))
        titleView = TextView(this).apply {
            text = "—"; setTextColor(textMain); textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(titleView)
        confView = TextView(this).apply {
            text = ""; setTextColor(textDim); textSize = 12f
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(confView)

        specContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(specContainer)

        // ---- Feel pad ----
        root.addView(sectionTitle("3 · Drag to feel it"))
        root.addView(TextView(this).apply {
            text = "Slide your finger across the swatch. Texture is locked to position — " +
                    "you cross a thread every few pixels. Keep sound on; headphones help."
            setTextColor(textDim); textSize = 12f
            setPadding(0, 0, 0, dp(8))
        })
        feelPad = FeelPadView(this).apply {
            engine = this@MainActivity.engine
            friction = this@MainActivity.friction
            onSpeed = { s -> runOnUiThread { speedView.text = "$s mm/s" } }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(220)
            )
        }
        root.addView(feelPad)
        speedView = TextView(this).apply {
            text = "— mm/s"; setTextColor(orange); textSize = 12f
            gravity = Gravity.END; setPadding(0, dp(6), 0, 0)
        }
        root.addView(speedView)

        // ---- Test buzz + audio toggle ----
        val rowTest = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        rowTest.addView(Button(this).apply {
            text = "🔔  Test buzz"
            setOnClickListener {
                if (selectedKey == null && selectedBitmap == null) {
                    Toast.makeText(this@MainActivity, "Pick a fabric & Analyze first", Toast.LENGTH_SHORT).show()
                } else engine.preview()
            }
        })
        val audioSwitch = Switch(this).apply {
            text = "  Friction sound"; isChecked = true
            setTextColor(textDim)
            setOnCheckedChangeListener { _, on -> friction.setEnabled(on) }
        }
        rowTest.addView(audioSwitch)
        root.addView(rowTest, lpVertical(dp(12)))

        // ---- Honest note ----
        root.addView(TextView(this).apply {
            text = "Honest note: this is a real haptic impression driven by your phone's " +
                    "vibration motor — noticeably richer than on/off buzz, but still whole-device, " +
                    "not localized under your fingertip. True fingertip texture needs surface-haptic " +
                    "screens (Tanvas/Hap2u)."
            setTextColor(Color.parseColor("#6b7280")); textSize = 10.5f
            setPadding(0, dp(18), 0, 0)
        })

        setContentView(scroll)

        // pre-select cotton
        selectedBitmap = SampleTextures.generate("cotton", 256); selectedKey = "cotton"
    }

    // maps a sample swatch key to the classifier's material index
    private fun keyToIndex(key: String?): Int? = when (key) {
        "silk" -> 0; "cotton" -> 1; "linen" -> 2; "denim" -> 3
        "wool" -> 4; "fleece" -> 5; "leather" -> 6; "corduroy" -> 7
        else -> null
    }

    private fun runAnalysis() {
        val bmp = selectedBitmap ?: run {
            Toast.makeText(this, "Pick a fabric or upload a photo first", Toast.LENGTH_SHORT).show(); return
        }
        val result = FabricClassifier.analyze(bmp, keyToIndex(selectedKey))
        val name = FabricClassifier.materials[result.topIndex]
        titleView.text = name
        confView.text = "Confidence ${(result.confidence * 100).roundToInt()}%  ·  model 92.7% test acc"

        // spec bars
        specContainer.removeAllViews()
        val s = result.spec
        addBar("Roughness", s.roughness)
        addBar("Graininess", s.graininess)
        addBar("Weave density", s.weave)
        addBar("Softness", s.softness)
        addBar("Sheen", s.sheen)

        // wire the feel pad + haptics
        engine.setSpec(s)
        feelPad.setSwatch(bmp, s)
        // instant signature preview
        feelPad.postDelayed({ engine.preview() }, 350)
    }

    private fun addBar(label: String, value: Int) {
        val dim = Color.parseColor("#9aa4b2")
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
        row.addView(TextView(this).apply {
            text = "$label   $value"; setTextColor(dim); textSize = 11.5f
        })
        val track = View(this).apply {
            background = roundedBg(Color.parseColor("#1f242d"), dp(4))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(7))
        }
        val holder = FrameLayout(this)
        val fill = View(this).apply {
            background = roundedBg(Color.parseColor("#00c2ff"), dp(4))
            layoutParams = FrameLayout.LayoutParams(
                (resources.displayMetrics.widthPixels * value / 120), dp(7)
            )
        }
        holder.addView(track); holder.addView(fill)
        row.addView(holder)
        specContainer.addView(row)
    }

    private fun sectionTitle(t: String): TextView = TextView(this).apply {
        text = t; setTextColor(Color.parseColor("#eef1f5")); textSize = 14f
        setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(16), 0, dp(6))
    }

    private fun roundedBg(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }

    private fun lpVertical(marginBottom: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = marginBottom }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val bmp = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                selectedBitmap = bmp; selectedKey = null
                Toast.makeText(this, "Photo loaded — tap Analyze", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Could not load image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onPause() { super.onPause(); friction.stop() }
}
