package com.tactiletouch

import android.content.Context
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Tactile spec produced by the ML model for a fabric (all 0..100).
 */
data class TactileSpec(
    val roughness: Int,
    val graininess: Int,
    val weave: Int,
    val softness: Int,
    val stiffness: Int,
    val sheen: Int
)

/**
 * HapticEngine — converts a fabric's tactile spec + live finger motion into
 * REAL Android vibration with amplitude / sharpness control.
 *
 * KEY IDEAS (why this beats a web page's on/off buzz):
 *  1. POSITION-LOCKED GRAIN — a "thread bump" fires every time the finger
 *     travels one thread-pitch (in px), NOT on a fixed timer. Texture is
 *     spatial: slow drag = spread-out bumps, fast = closer. This removes the
 *     continuous "electric shock" buzz.
 *  2. REAL INTENSITY — API 26+ amplitude (1..255) and API 30+ haptic
 *     PRIMITIVES (TICK / CLICK with a 0..1 scale) give soft threads vs. hard
 *     ridges — impossible via the web Vibration API.
 *  3. SHARPNESS mapping — coarse/dense weave => crisp CLICK; soft/plush =>
 *     dull TICK / longer low-amplitude pulse.
 *
 * HONEST LIMIT: this is still the phone's single motor buzzing the whole
 * body. It is a far more convincing "haptic impression" than on/off buzz, but
 * it is NOT localized fingertip texture — that needs surface-haptic hardware.
 */
class HapticEngine(context: Context) {

    private val vibrator: Vibrator = run {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    val hasVibrator: Boolean get() = vibrator.hasVibrator()
    val hasAmplitudeControl: Boolean
        get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vibrator.hasAmplitudeControl()
    private val supportsPrimitives: Boolean
        get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

    /** Human-readable capability tier for the UI. */
    fun capabilityLabel(): String = when {
        !hasVibrator -> "No vibration motor — audio/visual only"
        supportsPrimitives -> "Full haptics: scaled primitives (best feel)"
        hasAmplitudeControl -> "Good haptics: amplitude control"
        else -> "Basic haptics: on/off pulses"
    }

    private var spec: TactileSpec? = null
    private var accumPx = 0f
    private var lastTapNs = 0L

    fun setSpec(s: TactileSpec) { spec = s }

    /** px the finger must travel between thread "bumps": dense weave = smaller. */
    private fun grainSpacingPx(s: TactileSpec): Float {
        val weave = s.weave / 100f
        val grain = s.graininess / 100f
        return 34f - weave * 18f - grain * 8f     // ~8px (denim) .. 34px (silk)
    }

    /** Called when a drag begins. */
    fun begin() {
        accumPx = 0f
        lastTapNs = 0L
    }

    /**
     * Feed incremental finger movement.
     * @param dx,dy movement in px since last event
     * @param speed01 normalized speed 0..1
     */
    fun onMove(dx: Float, dy: Float, speed01: Float) {
        val s = spec ?: return
        accumPx += hypot(dx, dy)
        val spacing = grainSpacingPx(s)
        // Emit at most one grain per event to avoid merging into a buzz,
        // but if the finger moved far this frame, allow the accumulator to
        // carry over so fast swipes still feel denser.
        if (accumPx >= spacing) {
            accumPx -= spacing
            val now = System.nanoTime()
            if (now - lastTapNs < 18_000_000L) return   // 18ms hard floor
            lastTapNs = now
            emitGrain(s, speed01)
        }
    }

    fun end() {
        try { vibrator.cancel() } catch (_: Exception) {}
        accumPx = 0f
    }

    /** One "thread bump" — mapped to intensity + sharpness. */
    private fun emitGrain(s: TactileSpec, speed01: Float) {
        if (!hasVibrator) return
        val rough = s.roughness / 100f
        val soft = s.softness / 100f
        val weave = s.weave / 100f

        // intensity 0..1: hard/coarse hit harder, plush gentler
        val intensity = (0.25f + rough * 0.6f - soft * 0.2f + speed01 * 0.1f)
            .coerceIn(0.05f, 1f)
        // sharpness proxy: coarse & dense weave => crisp
        val sharp = (0.2f + rough * 0.5f + weave * 0.3f).coerceIn(0f, 1f)

        when {
            supportsPrimitives -> {
                val primitive = if (sharp > 0.5f)
                    VibrationEffect.Composition.PRIMITIVE_CLICK
                else
                    VibrationEffect.Composition.PRIMITIVE_TICK
                val comp = VibrationEffect.startComposition()
                    .addPrimitive(primitive, intensity)   // scale = intensity
                    .compose()
                vibrator.vibrate(comp)
            }
            hasAmplitudeControl -> {
                val amp = (intensity * 255f).toInt().coerceIn(1, 255)
                val durMs = if (sharp > 0.5f) 10L else 18L
                vibrator.vibrate(VibrationEffect.createOneShot(durMs, amp))
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O -> {
                vibrator.vibrate(VibrationEffect.createOneShot(12L, VibrationEffect.DEFAULT_AMPLITUDE))
            }
            else -> {
                @Suppress("DEPRECATION")
                vibrator.vibrate(12L)
            }
        }
    }

    /**
     * One-shot "signature" preview so the user feels the fabric instantly
     * after analysis — a short sequence of spaced, spec-shaped taps.
     */
    fun preview() {
        val s = spec ?: return
        if (!hasVibrator) return
        val rough = s.roughness / 100f
        val weave = s.weave / 100f
        val grains = (4 + (weave * 6).toInt()).coerceIn(4, 12)

        if (supportsPrimitives) {
            val comp = VibrationEffect.startComposition()
            var delay = 0
            for (i in 0 until grains) {
                val primitive = if (rough > 0.5f)
                    VibrationEffect.Composition.PRIMITIVE_CLICK
                else
                    VibrationEffect.Composition.PRIMITIVE_TICK
                comp.addPrimitive(primitive, (0.3f + rough * 0.6f).coerceIn(0.1f, 1f), delay)
                delay = (90 - weave * 45).toInt().coerceAtLeast(40)   // gap between grains
            }
            vibrator.vibrate(comp.compose())
        } else {
            // waveform: [wait, buzz, wait, buzz, ...]
            val timings = ArrayList<Long>()
            val amps = ArrayList<Int>()
            timings.add(0); amps.add(0)
            for (i in 0 until grains) {
                timings.add((8 + rough * 12).toLong()); amps.add((rough * 255).toInt().coerceIn(60, 255))
                timings.add((120 - weave * 45).toLong().coerceAtLeast(45)); amps.add(0)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && hasAmplitudeControl) {
                vibrator.vibrate(VibrationEffect.createWaveform(timings.toLongArray(), amps.toIntArray(), -1))
            } else {
                val onOff = timings.toLongArray()
                @Suppress("DEPRECATION")
                vibrator.vibrate(onOff, -1)
            }
        }
    }
}
