package com.tactiletouch

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * FeelPadView — the interactive swatch the user drags a finger across.
 * Tracks position + speed, drives the HapticEngine with position-locked
 * grains, and paints a "stick-slip" contact ring (pseudo-haptic reinforcement).
 */
class FeelPadView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var engine: HapticEngine? = null
    var friction: FrictionAudio? = null
    var onSpeed: ((Int) -> Unit)? = null

    private var bitmap: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.WHITE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val dst = RectF()

    private var touching = false
    private var lastX = 0f; private var lastY = 0f; private var lastT = 0L
    private var slipX = 0f; private var slipY = 0f
    private var spec: TactileSpec? = null

    fun setSwatch(bmp: Bitmap, s: TactileSpec) {
        bitmap = bmp; spec = s; invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = bitmap ?: return
        dst.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawBitmap(bmp, null, dst, paint)
        if (touching) {
            canvas.drawCircle(slipX, slipY, 34f, ringPaint)
            canvas.drawCircle(slipX, slipY, 6f, dotPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val s = spec ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                lastX = event.x; lastY = event.y; lastT = System.currentTimeMillis()
                slipX = event.x; slipY = event.y
                engine?.begin()
                friction?.start()
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val now = System.currentTimeMillis()
                val dt = (now - lastT).coerceAtLeast(1).toFloat()
                val dx = event.x - lastX; val dy = event.y - lastY
                val dist = hypot(dx, dy)
                val speed01 = ((dist / dt) / 1.5f).coerceIn(0f, 1f)

                // pseudo-haptic stick-slip: ring lags then snaps, more "grab"
                // for denser weave
                val grab = 0.12f + (s.weave / 100f) * 0.30f
                slipX += (event.x - slipX) * (1 - grab)
                slipY += (event.y - slipY) * (1 - grab)

                engine?.onMove(dx, dy, speed01)
                friction?.update(speed01, s.roughness / 100f)
                onSpeed?.invoke((speed01 * 450).toInt())

                lastX = event.x; lastY = event.y; lastT = now
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touching = false
                engine?.end()
                friction?.stop()
                onSpeed?.invoke(0)
                invalidate()
            }
        }
        return true
    }
}
