package com.tactiletouch

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.random.Random

/**
 * Generates characteristic fabric swatch bitmaps procedurally, so the demo
 * ships with sample fabrics without bundling image assets. The classifier
 * then analyzes these exactly like a user-uploaded photo.
 */
object SampleTextures {

    val keys = listOf("silk", "cotton", "denim", "fleece", "linen", "wool", "leather", "corduroy")
    val labels = mapOf(
        "silk" to "Silk", "cotton" to "Cotton", "denim" to "Denim", "fleece" to "Fleece",
        "linen" to "Linen", "wool" to "Wool", "leather" to "Leather", "corduroy" to "Corduroy"
    )

    private val baseColor = mapOf(
        "silk" to Color.rgb(201, 184, 232), "cotton" to Color.rgb(127, 168, 208),
        "denim" to Color.rgb(47, 79, 122), "fleece" to Color.rgb(216, 160, 160),
        "linen" to Color.rgb(203, 181, 138), "wool" to Color.rgb(138, 111, 90),
        "leather" to Color.rgb(107, 74, 47), "corduroy" to Color.rgb(122, 90, 58)
    )

    fun generate(key: String, size: Int = 256): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val rnd = Random(key.hashCode())
        val base = baseColor[key] ?: Color.GRAY
        val br = Color.red(base); val bg = Color.green(base); val bb = Color.blue(base)

        fun mix(v: Double): Int {
            val add = (v * 255).toInt()
            val r = (br + add).coerceIn(0, 255)
            val g = (bg + add).coerceIn(0, 255)
            val b = (bb + add).coerceIn(0, 255)
            return Color.rgb(r, g, b)
        }

        val px = IntArray(size * size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                val v: Double = when (key) {
                    "silk" -> {
                        val band = (Math.sin((x + y) / 22.0) * 0.5 + 0.5)
                        band * 0.12 * rnd.nextDouble() + (if (rnd.nextDouble() < 0.002) 0.3 else 0.0)
                    }
                    "denim" -> {
                        val twill = if ((x + y) % 4 == 0) 0.22 else 0.0
                        twill + rnd.nextDouble() * 0.10 + (if (rnd.nextDouble() < 0.004) 0.4 else 0.0)
                    }
                    "fleece", "wool" -> rnd.nextDouble() * 0.45
                    "linen" -> {
                        val warp = if (x % 3 == 0) 0.16 else 0.0
                        val weft = if (y % 3 == 0) 0.16 else 0.0
                        warp + weft + rnd.nextDouble() * 0.12
                    }
                    "corduroy" -> {
                        val wale = Math.sin(x / 6.0)
                        val rib = if (wale > 0.4) 0.28 else if (wale < -0.4) -0.15 else 0.0
                        Math.max(0.0, rib) + rnd.nextDouble() * 0.08
                    }
                    "leather" -> {
                        val cell = Math.sin(x / 9.0) * Math.cos(y / 11.0)
                        Math.abs(cell) * 0.14 + rnd.nextDouble() * 0.05
                    }
                    else -> { // cotton
                        val knit = (if (x % 5 < 2) 0.1 else 0.0) + (if (y % 5 < 2) 0.1 else 0.0)
                        knit + rnd.nextDouble() * 0.14
                    }
                }
                px[y * size + x] = mix(v)
            }
        }
        bmp.setPixels(px, 0, size, 0, 0, size, size)
        return bmp
    }
}
