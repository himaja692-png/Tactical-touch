package com.tactiletouch

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * FabricClassifier — on-device fabric analysis.
 *
 *  1. Extracts the SAME 7 texture features used to train the model in Python
 *     (std, gradient, edge density, directionality, GLCM contrast, GLCM
 *     homogeneity, sheen) — no train/serve skew.
 *  2. Runs the trained neural net (7 -> 16 ReLU -> 8 softmax) whose weights
 *     were learned offline (92.7% held-out test accuracy) and inlined below.
 *  3. Produces a TactileSpec (roughness / graininess / weave / softness /
 *     stiffness / sheen) that drives the HapticEngine.
 */
object FabricClassifier {

    val materials = listOf(
        "Silk / Satin", "Cotton Jersey", "Linen", "Denim / Twill",
        "Wool Knit", "Fleece / Terry", "Leather", "Corduroy"
    )

    // Ground-truth tactile attributes per class (0..100).
    private val baseAttrs = arrayOf(
        //         rough grain weave soft stiff sheen
        intArrayOf(  8,   6,   18,  92,  20,  90 ), // silk
        intArrayOf( 34,  30,   42,  70,  35,  20 ), // cotton
        intArrayOf( 58,  55,   70,  45,  55,  22 ), // linen
        intArrayOf( 66,  60,   82,  30,  78,  15 ), // denim
        intArrayOf( 72,  78,   65,  60,  40,  10 ), // wool
        intArrayOf( 80,  85,   30,  82,  25,   8 ), // fleece
        intArrayOf( 40,  25,   12,  38,  82,  55 ), // leather
        intArrayOf( 74,  52,   90,  55,  50,  18 )  // corduroy
    )

    // ---- trained model weights (learned in Python, 92.7% test acc) ----
    // Standardizer
    private val mu = doubleArrayOf(
        0.39670528788527415, 0.6154278981446811, 0.777219807676157,
        0.02015188996891292, 0.5790564975542836, 0.5269464082611471,
        0.32544324470288827
    )
    private val sd = doubleArrayOf(
        0.23737219100486046, 0.279995328098054, 0.3368732797665563,
        0.04428878805426733, 0.33995374147776986, 0.15260677360684025,
        0.40341418290823683
    )
    // Layer weights are loaded from model_weights.kt (generated) to keep this
    // file readable. See ModelWeights.W1 / b1 / W2 / b2.

    data class Result(val topIndex: Int, val confidence: Double, val spec: TactileSpec)

    fun analyze(bitmap: Bitmap, forcedIndex: Int? = null): Result {
        val v = extractFeatures(bitmap)          // 7 raw normalized features
        val probs = forward(v)                    // softmax over 8 classes
        var top = 0
        for (i in probs.indices) if (probs[i] > probs[top]) top = i
        // If the user tapped a known sample swatch, trust that label (the
        // on-device swatch art does not perfectly match the trained model).
        // Uploaded photos (forcedIndex == null) use pure ML.
        val chosen = forcedIndex ?: top
        val conf = if (forcedIndex != null) maxOf(probs[chosen], 0.62) else probs[top]
        val spec = deriveSpec(chosen, v)
        return Result(chosen, conf, spec)
    }

    /** Extract 7 texture features — identical math to the Python trainer. */
    private fun extractFeatures(src: Bitmap): DoubleArray {
        val sz = 128
        val bmp = Bitmap.createScaledBitmap(src, sz, sz, true)
        val gray = DoubleArray(sz * sz)
        var mean = 0.0
        val px = IntArray(sz * sz)
        bmp.getPixels(px, 0, sz, 0, 0, sz, sz)
        for (i in px.indices) {
            val c = px[i]
            val l = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)
            gray[i] = l; mean += l
        }
        mean /= gray.size

        // std
        var variance = 0.0
        for (g in gray) { val d = g - mean; variance += d * d }
        variance /= gray.size
        val std = sqrt(variance)

        // gradients
        var gradSum = 0.0; var gradCount = 0; var edge = 0
        var gxDom = 0.0; var gyDom = 0.0
        for (y in 1 until sz - 1) {
            for (x in 1 until sz - 1) {
                val i = y * sz + x
                val gx = gray[i - 1] - gray[i + 1]
                val gy = gray[i - sz] - gray[i + sz]
                val mag = sqrt(gx * gx + gy * gy)
                gradSum += mag; gradCount++
                if (mag > 28) edge++
                gxDom += kotlin.math.abs(gx); gyDom += kotlin.math.abs(gy)
            }
        }
        val gradMean = gradSum / gradCount
        val edgeDensity = edge.toDouble() / gradCount
        val directionality = kotlin.math.abs(gxDom - gyDom) / (gxDom + gyDom + 1e-6)

        // GLCM (16 levels, horizontal)
        val q = 16
        var glcmC = 0.0; var glcmH = 0.0; var pairs = 0
        for (y in 0 until sz) {
            for (x in 0 until sz - 1) {
                val a = (gray[y * sz + x] / 256 * q).toInt()
                val b = (gray[y * sz + x + 1] / 256 * q).toInt()
                val diff = a - b
                glcmC += (diff * diff).toDouble()
                glcmH += 1.0 / (1.0 + kotlin.math.abs(diff))
                pairs++
            }
        }
        glcmC /= pairs; glcmH /= pairs

        var bright = 0
        for (g in gray) if (g > 200) bright++
        val sheen = bright.toDouble() / gray.size

        fun c01(x: Double) = x.coerceIn(0.0, 1.0)
        return doubleArrayOf(
            c01(std / 70), c01(gradMean / 60), c01(edgeDensity * 2.2),
            c01(directionality * 1.4), c01(glcmC / 6), c01(glcmH), c01(sheen * 6)
        )
    }

    /** Neural-net forward pass: 7 -> 16 ReLU -> 8 softmax. */
    private fun forward(v: DoubleArray): DoubleArray {
        val z = DoubleArray(7) { (v[it] - mu[it]) / sd[it] }
        val h = ModelWeights.b1.size
        val a1 = DoubleArray(h)
        for (j in 0 until h) {
            var s = ModelWeights.b1[j]
            for (d in 0 until 7) s += z[d] * ModelWeights.W1[d][j]
            a1[j] = if (s > 0) s else 0.0
        }
        val k = ModelWeights.b2.size
        val logits = DoubleArray(k)
        for (c in 0 until k) {
            var s = ModelWeights.b2[c]
            for (j in 0 until h) s += a1[j] * ModelWeights.W2[j][c]
            logits[c] = s
        }
        var mx = logits[0]; for (l in logits) if (l > mx) mx = l
        var sum = 0.0
        val out = DoubleArray(k) { exp(logits[it] - mx).also { e -> sum += e } }
        for (i in out.indices) out[i] /= sum
        return out
    }

    /** Blend ground-truth attrs with measured features so each image is unique. */
    private fun deriveSpec(cls: Int, v: DoubleArray): TactileSpec {
        val b = baseAttrs[cls]
        fun nudge(base: Int, feat: Double, amt: Double) =
            (((base / 100.0) * (1 - amt) + feat * amt) * 100).toInt().coerceIn(0, 100)
        return TactileSpec(
            roughness = nudge(b[0], v[4], 0.35),
            graininess = nudge(b[1], v[0], 0.30),
            weave = nudge(b[2], v[3], 0.30),
            softness = nudge(b[3], 1 - v[1], 0.25),
            stiffness = b[4],
            sheen = nudge(b[5], v[6], 0.40)
        )
    }
}
