package com.tactiletouch

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.min
import kotlin.random.Random

/**
 * FrictionAudio — synthesizes a continuous "scrape/hiss" whose loudness and
 * timbre track finger speed and fabric roughness. This is the audio half of
 * the multisensory illusion: ears strongly influence perceived roughness, so
 * sound + haptics together feel far more like texture than the motor alone.
 *
 * Implemented with a streaming AudioTrack fed band-limited noise.
 */
class FrictionAudio {

    private val sampleRate = 44100
    private var track: AudioTrack? = null
    private var running = false
    @Volatile private var targetGain = 0f
    @Volatile private var gain = 0f
    @Volatile private var rough = 0.5f
    private var enabled = true

    fun setEnabled(on: Boolean) { enabled = on; if (!on) stop() }

    fun start() {
        if (!enabled || running) return
        val bufSize = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(2048)

        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        running = true
        track?.play()

        thread(start = true, isDaemon = true, name = "friction-audio") {
            val frame = ShortArray(512)
            // simple one-pole low-pass state for band-limiting the noise
            var lp = 0f
            while (running) {
                // smooth the gain toward target (avoids clicks)
                for (i in frame.indices) {
                    gain += (targetGain - gain) * 0.002f
                    // rough fabric => brighter/coarser (less filtering)
                    val alpha = 0.05f + rough * 0.35f
                    val white = Random.nextFloat() * 2f - 1f
                    lp += alpha * (white - lp)
                    val sample = lp * gain
                    frame[i] = (sample * 32767f).toInt()
                        .coerceIn(-32767, 32767).toShort()
                }
                track?.write(frame, 0, frame.size)
            }
        }
    }

    /** speed01: 0..1 finger speed; roughness01: 0..1 fabric roughness. */
    fun update(speed01: Float, roughness01: Float) {
        rough = roughness01
        targetGain = min(0.22f, speed01 * (0.06f + roughness01 * 0.20f))
    }

    fun stop() {
        targetGain = 0f
        running = false
        try {
            track?.stop()
            track?.release()
        } catch (_: Exception) {}
        track = null
        gain = 0f
    }
}
